#!/system/bin/sh

LOGFILE=/data/cache/magisk.log

log_print() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') | GPGPCDE DR : $1" >> "$LOGFILE"
}

# Wait for Android boot completion
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

# Wait until package manager is ready
until pm list users >/dev/null 2>&1; do
    sleep 2
done

sleep 1

# Try multiple times to ensure restriction is removed
MAX_ATTEMPTS=10
ATTEMPT=1

while [ "$ATTEMPT" -le "$MAX_ATTEMPTS" ]; do
    log_print "Attempt $ATTEMPT removing restriction"

    pm set-user-restriction no_install_unknown_sources_globally 0

    sleep 1

    # Verify restriction removed
    if ! dumpsys user | grep -q no_install_unknown_sources_globally; then
        log_print "Restriction successfully removed"
        break
    fi

    log_print "Restriction still present"

    ATTEMPT=$((ATTEMPT + 1))
    sleep 2
done

if [ "$ATTEMPT" -gt "$MAX_ATTEMPTS" ]; then
    log_print "Max attempts reached, restriction may still exist"
fi

log_print "Script finished"
