# Example

Run:
- `su -c "dumpsys user"`
- or `su -c "dumpsys user" | grep no_install_unknown_sources_globally`


Results:

```
Current user: 0

Users:
  UserInfo{0:null:4c13} serialNo=0 isPrimary=true
    Type: android.os.usertype.full.SYSTEM
    Flags: 19475 (ADMIN|FULL|INITIALIZED|MAIN|PRIMARY|SYSTEM)
    State: RUNNING_UNLOCKED
    Created: <unknown>
    Last logged in: -
    Last logged in fingerprint: -
    Start time: -
    Unlock time: -
    Last entered foreground: -
    Has profile owner: false
    Restrictions:
      no_install_unknown_sources_globally
    Device policy restrictions:
      null
    Effective restrictions:
      no_install_unknown_sources_globally
    UserProperties:
        mPropertiesPresent=0
        mShowInLauncher=0
        mStartWithParent=false
        mShowInSettings=0
        mInheritDevicePolicy=0
        mUseParentsContacts=false
        mUpdateCrossProfileIntentFiltersOnOTA=false
        mCrossProfileIntentFilterAccessControl=0
        mCrossProfileIntentResolutionStrategy=0
        mMediaSharedWithParent=false
        mCredentialShareableWithParent=false
        mDeleteAppWithParent=false
    Ignore errors preparing storage: false

Device properties:
  Device policy global restrictions:
    null
  Guest restrictions:
    no_sms
    no_install_unknown_sources
    no_config_wifi
    no_config_credentials
    no_outgoing_calls

  Device managed: false
  Started users state: [0=RUNNING_UNLOCKED]
  Cached user IDs: [0]
  Cached user IDs (including pre-created): [0]

UserVisibilityMediator
  DBG: false
  Current user id: 0
  Visible users: [0]
  Number of started visible user / profile group mappings: 1
    u:0 -> pg:0
  Supports visible background users on displays: true
  Supports visible background users on default display: false
  Number of user / display mappings: 0
  Number of extra display / user mappings: 0
  Number of listeners: 2
    0: com.android.server.accessibility.AccessibilityManagerService$$ExternalSyntheticLambda31@94fbc20
    1: com.android.server.location.injector.SystemUserInfoHelper$$ExternalSyntheticLambda0@30509d9


  Max users: 16 (limit reached: false)
  Supports switchable users: false
  All guests ephemeral: false
  Force ephemeral users: false
  Is headless-system mode: false
  User version: 11
  Owner name: Owner
  Boot user: -10000

Number of listeners for
  restrictions: 3
  user lifecycle events: 2

User types version: 0
User types (9 types):
    android.os.usertype.profile.KIWI:
        mName: android.os.usertype.profile.KIWI
        mBaseType: PROFILE
        mEnabled: true
        mMaxAllowed: -1
        mMaxAllowedPerParent: 14
        mDefaultUserInfoFlags: 0
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=2
            mStartWithParent=true
            mShowInSettings=0
            mInheritDevicePolicy=1
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=true
            mCrossProfileIntentFilterAccessControl=10
            mCrossProfileIntentResolutionStrategy=1
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=true
            mDeleteAppWithParent=false
        mDefaultRestrictions:
            no_wallpaper
        mIconBadge: 0
        mBadgePlain: 0
        mBadgeNoBackground: 0
        mBadgeLabels.length: 0(null)
        mBadgeColors.length: 0(null)
        mDarkThemeBadgeColors.length: 0(null)
    android.os.usertype.full.GUEST:
        mName: android.os.usertype.full.GUEST
        mBaseType: FULL
        mEnabled: true
        mMaxAllowed: 1
        mMaxAllowedPerParent: -1
        mDefaultUserInfoFlags: GUEST
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=0
            mStartWithParent=false
            mShowInSettings=0
            mInheritDevicePolicy=0
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=false
            mCrossProfileIntentFilterAccessControl=0
            mCrossProfileIntentResolutionStrategy=0
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=false
            mDeleteAppWithParent=false
        mDefaultRestrictions:
            no_sms
            no_install_unknown_sources
            no_config_wifi
            no_config_credentials
            no_outgoing_calls
        mIconBadge: 0
        mBadgePlain: 0
        mBadgeNoBackground: 0
        mBadgeLabels.length: 0(null)
        mBadgeColors.length: 0(null)
        mDarkThemeBadgeColors.length: 0(null)
    android.os.usertype.profile.MANAGED:
        mName: android.os.usertype.profile.MANAGED
        mBaseType: PROFILE
        mEnabled: true
        mMaxAllowed: -1
        mMaxAllowedPerParent: 1
        mDefaultUserInfoFlags: MANAGED_PROFILE
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=1
            mStartWithParent=true
            mShowInSettings=1
            mInheritDevicePolicy=0
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=false
            mCrossProfileIntentFilterAccessControl=0
            mCrossProfileIntentResolutionStrategy=0
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=true
            mDeleteAppWithParent=false
        mDefaultRestrictions:
            no_wallpaper
        mIconBadge: 17302416
        mBadgePlain: 17302411
        mBadgeNoBackground: 17302413
        mBadgeLabels.length: 3
        mBadgeColors.length: 3
        mDarkThemeBadgeColors.length: 3
    android.os.usertype.system.HEADLESS:
        mName: android.os.usertype.system.HEADLESS
        mBaseType: SYSTEM
        mEnabled: true
        mMaxAllowed: 1
        mMaxAllowedPerParent: -1
        mDefaultUserInfoFlags: ADMIN|PRIMARY
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=0
            mStartWithParent=false
            mShowInSettings=0
            mInheritDevicePolicy=0
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=false
            mCrossProfileIntentFilterAccessControl=0
            mCrossProfileIntentResolutionStrategy=0
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=false
            mDeleteAppWithParent=false
        config_defaultFirstUserRestrictions:
            none
        mIconBadge: 0
        mBadgePlain: 0
        mBadgeNoBackground: 0
        mBadgeLabels.length: 0(null)
        mBadgeColors.length: 0(null)
        mDarkThemeBadgeColors.length: 0(null)
    android.os.usertype.full.SYSTEM:
        mName: android.os.usertype.full.SYSTEM
        mBaseType: FULL|SYSTEM
        mEnabled: true
        mMaxAllowed: 1
        mMaxAllowedPerParent: -1
        mDefaultUserInfoFlags: ADMIN|MAIN|PRIMARY
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=0
            mStartWithParent=false
            mShowInSettings=0
            mInheritDevicePolicy=0
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=false
            mCrossProfileIntentFilterAccessControl=0
            mCrossProfileIntentResolutionStrategy=0
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=false
            mDeleteAppWithParent=false
        config_defaultFirstUserRestrictions:
            none
        mIconBadge: 0
        mBadgePlain: 0
        mBadgeNoBackground: 0
        mBadgeLabels.length: 0(null)
        mBadgeColors.length: 0(null)
        mDarkThemeBadgeColors.length: 0(null)
    android.os.usertype.full.SECONDARY:
        mName: android.os.usertype.full.SECONDARY
        mBaseType: FULL
        mEnabled: true
        mMaxAllowed: -1
        mMaxAllowedPerParent: -1
        mDefaultUserInfoFlags: 0
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=0
            mStartWithParent=false
            mShowInSettings=0
            mInheritDevicePolicy=0
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=false
            mCrossProfileIntentFilterAccessControl=0
            mCrossProfileIntentResolutionStrategy=0
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=false
            mDeleteAppWithParent=false
        mDefaultRestrictions:
            no_sms
            no_outgoing_calls
        mIconBadge: 0
        mBadgePlain: 0
        mBadgeNoBackground: 0
        mBadgeLabels.length: 0(null)
        mBadgeColors.length: 0(null)
        mDarkThemeBadgeColors.length: 0(null)
    android.os.usertype.full.RESTRICTED:
        mName: android.os.usertype.full.RESTRICTED
        mBaseType: FULL
        mEnabled: true
        mMaxAllowed: -1
        mMaxAllowedPerParent: -1
        mDefaultUserInfoFlags: RESTRICTED
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=0
            mStartWithParent=false
            mShowInSettings=0
            mInheritDevicePolicy=0
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=false
            mCrossProfileIntentFilterAccessControl=0
            mCrossProfileIntentResolutionStrategy=0
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=false
            mDeleteAppWithParent=false
        mDefaultRestrictions:
            null
        mIconBadge: 0
        mBadgePlain: 0
        mBadgeNoBackground: 0
        mBadgeLabels.length: 0(null)
        mBadgeColors.length: 0(null)
        mDarkThemeBadgeColors.length: 0(null)
    android.os.usertype.full.DEMO:
        mName: android.os.usertype.full.DEMO
        mBaseType: FULL
        mEnabled: true
        mMaxAllowed: -1
        mMaxAllowedPerParent: -1
        mDefaultUserInfoFlags: DEMO
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=0
            mStartWithParent=false
            mShowInSettings=0
            mInheritDevicePolicy=0
            mUseParentsContacts=false
            mUpdateCrossProfileIntentFiltersOnOTA=false
            mCrossProfileIntentFilterAccessControl=0
            mCrossProfileIntentResolutionStrategy=0
            mMediaSharedWithParent=false
            mCredentialShareableWithParent=false
            mDeleteAppWithParent=false
        mDefaultRestrictions:
            null
        mIconBadge: 0
        mBadgePlain: 0
        mBadgeNoBackground: 0
        mBadgeLabels.length: 0(null)
        mBadgeColors.length: 0(null)
        mDarkThemeBadgeColors.length: 0(null)
    android.os.usertype.profile.CLONE:
        mName: android.os.usertype.profile.CLONE
        mBaseType: PROFILE
        mEnabled: true
        mMaxAllowed: -1
        mMaxAllowedPerParent: 1
        mDefaultUserInfoFlags: 0
        mLabel: 0
        UserProperties:
            mPropertiesPresent=11111111111
            mShowInLauncher=0
            mStartWithParent=true
            mShowInSettings=0
            mInheritDevicePolicy=1
            mUseParentsContacts=true
            mUpdateCrossProfileIntentFiltersOnOTA=true
            mCrossProfileIntentFilterAccessControl=10
            mCrossProfileIntentResolutionStrategy=1
            mMediaSharedWithParent=true
            mCredentialShareableWithParent=true
            mDeleteAppWithParent=true
        mDefaultRestrictions:
            null
        mIconBadge: 17302392
        mBadgePlain: 17302391
        mBadgeNoBackground: 17302391
        mBadgeLabels.length: 1
        mBadgeColors.length: 1
        mDarkThemeBadgeColors.length: 1

Whitelisted packages per user type
  Mode: 13 (enforced) (implicit)
  Legend
    0 -> android.os.usertype.full.DEMO
    1 -> android.os.usertype.full.GUEST
    2 -> android.os.usertype.full.RESTRICTED
    3 -> android.os.usertype.full.SECONDARY
    4 -> android.os.usertype.full.SYSTEM
    5 -> android.os.usertype.profile.CLONE
    6 -> android.os.usertype.profile.KIWI
    7 -> android.os.usertype.profile.MANAGED
    8 -> android.os.usertype.system.HEADLESS
  6 packages:
    android: 0 1 2 3 4 5 6 7 8
    com.android.providers.settings: 0 1 2 3 4 5 6 7 8
    com.android.settings: 0 1 2 3 4 5 6 7 8
    com.android.wallpaperbackup: 0 1 2 3 4
    com.android.providers.media.module: 0 1 2 3 4 6 7 8
    com.android.bluetooth: 0 1 2 3 4 6 7 8
  No errors
  No warnings
```
