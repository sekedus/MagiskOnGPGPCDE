ui_print "Cleaning up Google Play Store data and cache"

am force-stop com.android.vending
pm clear com.android.vending

ui_print "Initial cleanup done"
