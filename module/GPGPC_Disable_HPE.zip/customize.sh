ui_print "Cleaning up Google Play Store data and cache"

am force-stop com.android.vending || true
pm clear com.android.vending || true

ui_print "Initial cleanup done"
